@echo off
setlocal

cd /d "%~dp0"

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set "PYTHON_CMD=python"
) else (
    where py >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        set "PYTHON_CMD=py"
    ) else (
        echo Python was not found in PATH.
        echo Activate your virtual environment and run this launcher again.
        pause
        exit /b 1
    )
)

%PYTHON_CMD% -m streamlit run app.py
set "EXIT_CODE=%ERRORLEVEL%"

if not "%EXIT_CODE%"=="0" (
    echo.
    echo Streamlit did not start successfully.
    echo If needed, install dependencies with: pip install -r requirements.txt
    pause
)

exit /b %EXIT_CODE%
