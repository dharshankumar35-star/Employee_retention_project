import joblib
import pandas as pd
import streamlit as st
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
MODEL_PATH = PROJECT_ROOT / "outputs" / "models" / "best_model.pkl"
BANNER_IMAGE_URL = "https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=1800&q=80"

FEATURE_COLUMNS = [
    "city",
    "city_development_index",
    "gender",
    "relevent_experience",
    "enrolled_university",
    "education_level",
    "major_discipline",
    "company_size",
    "company_type",
    "training_hours",
    "experience_num",
    "last_new_job_num",
    "training_per_experience",
    "is_fresher",
]

st.set_page_config(page_title="Employee Retention Prediction", layout="centered")


def convert_experience(value):
    if value == ">20":
        return 21
    if value == "<1":
        return 0
    return int(value)


def convert_last_new_job(value):
    if str(value).lower() == "never":
        return 0
    if value == ">4":
        return 5
    return int(value)


@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


def get_known_categories(pipeline, feature_name):
    preprocessor = pipeline.named_steps.get("preprocessor")
    if preprocessor is None:
        return []

    for transformer_name, transformer, columns in preprocessor.transformers_:
        if transformer_name != "cat":
            continue

        onehot = transformer.named_steps.get("onehot")
        if onehot is None:
            return []

        for column_name, categories in zip(columns, onehot.categories_):
            if column_name == feature_name:
                return [str(value) for value in categories]

    return []


def build_input_dataframe(values):
    experience_num = convert_experience(values["experience"])
    last_new_job_num = convert_last_new_job(values["last_new_job"])
    training_per_experience = values["training_hours"] / (experience_num + 1)
    is_fresher = 1 if experience_num <= 1 else 0

    return pd.DataFrame(
        [
            {
                "city": values["city"],
                "city_development_index": values["city_development_index"],
                "gender": values["gender"],
                "relevent_experience": values["relevent_experience"],
                "enrolled_university": values["enrolled_university"],
                "education_level": values["education_level"],
                "major_discipline": values["major_discipline"],
                "company_size": values["company_size"],
                "company_type": values["company_type"],
                "training_hours": values["training_hours"],
                "experience_num": experience_num,
                "last_new_job_num": last_new_job_num,
                "training_per_experience": training_per_experience,
                "is_fresher": is_fresher,
            }
        ]
    )[FEATURE_COLUMNS]


model = load_model()
KNOWN_CITIES = set(get_known_categories(model, "city"))
RELEVANT_EXPERIENCE_OPTIONS = get_known_categories(model, "relevent_experience") or [
    "Has relevent experience",
    "No relevent experience",
]

st.title("Employee Retention Prediction")
st.caption("Predict whether a candidate is likely looking for a job change.")
st.image(BANNER_IMAGE_URL, use_container_width=True)

with st.expander("Model Path"):
    st.write(str(MODEL_PATH))

col1, col2 = st.columns(2)
with col1:
    city = st.text_input("City", value="city_103", help="Use values like city_103 from the training data.")
    city_development_index = st.slider("City Development Index", 0.0, 1.0, 0.75, 0.001)
    gender = st.selectbox("Gender", ["Male", "Female", "Other", "Unknown"], index=0)
    relevent_experience = st.selectbox(
        "Relevant Experience",
        RELEVANT_EXPERIENCE_OPTIONS,
        index=0,
    )
    enrolled_university = st.selectbox(
        "Enrolled University",
        ["no_enrollment", "Part time course", "Full time course", "Unknown"],
        index=0,
    )

with col2:
    education_level = st.selectbox(
        "Education Level",
        ["Primary School", "High School", "Graduate", "Masters", "Phd", "Unknown"],
        index=2,
    )
    major_discipline = st.selectbox(
        "Major Discipline",
        ["STEM", "Humanities", "Business Degree", "Arts", "No Major", "Other", "Unknown"],
        index=0,
    )
    company_size = st.selectbox(
        "Company Size",
        ["<10", "10/49", "50-99", "100-500", "500-999", "1000-4999", "5000-9999", "10000+", "Unknown"],
        index=8,
    )
    company_type = st.selectbox(
        "Company Type",
        ["Pvt Ltd", "Funded Startup", "Public Sector", "Early Stage Startup", "NGO", "Other", "Unknown"],
        index=6,
    )

training_hours = st.number_input("Training Hours", min_value=0, max_value=500, value=36, step=1)
exp_col1, exp_col2 = st.columns(2)
with exp_col1:
    experience = st.selectbox("Experience", ["<1"] + [str(i) for i in range(1, 21)] + [">20"], index=5)
with exp_col2:
    last_new_job = st.selectbox("Last New Job", ["never", "1", "2", "3", "4", ">4"], index=0)

threshold = st.slider("Decision Threshold", 0.1, 0.9, 0.5, 0.01)
cleaned_city = city.strip()

if KNOWN_CITIES and cleaned_city and cleaned_city not in KNOWN_CITIES:
    st.info(
        "This city was not seen during training. The model can still score it, "
        "but it will treat the city as an unseen category."
    )

if st.button("Predict", use_container_width=True):
    if not cleaned_city:
        st.error("City cannot be empty.")
        st.stop()

    input_df = build_input_dataframe(
        {
            "city": cleaned_city,
            "city_development_index": float(city_development_index),
            "gender": gender,
            "relevent_experience": relevent_experience,
            "enrolled_university": enrolled_university,
            "education_level": education_level,
            "major_discipline": major_discipline,
            "company_size": company_size,
            "company_type": company_type,
            "training_hours": int(training_hours),
            "experience": experience,
            "last_new_job": last_new_job,
        }
    )

    probability = float(model.predict_proba(input_df)[:, 1][0])
    prediction = 1 if probability >= threshold else 0

    st.metric("Probability of Job Change", f"{probability:.3f}")
    if prediction == 1:
        st.error("Prediction: Likely looking for a job change (1)")
    else:
        st.success("Prediction: Not looking for a job change (0)")

    if probability >= 0.7:
        st.warning("Suggested action: Prioritize a retention conversation and review growth opportunities.")
    elif probability >= 0.4:
        st.info("Suggested action: Monitor engagement and explore training or role-fit interventions.")
    else:
        st.write("Suggested action: Maintain regular engagement and development planning.")

    with st.expander("Input features sent to the model"):
        st.dataframe(input_df)
