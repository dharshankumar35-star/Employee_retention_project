# Employee Retention Prediction

This project predicts whether a data science professional is likely to look for a job change. It includes exploratory analysis, preprocessing, feature engineering, model comparison, saved predictions, and a Streamlit app for interactive scoring.

## Institute Deliverables

This folder is organized to match the institute submission requirements:

- `Employee_Retention_Prediction.ipynb`: Jupyter notebook with EDA, preprocessing, feature engineering, model training, and evaluation
- `Employee_Retention_Prediction_Report.docx`: Final written report
- `Employee_Retention_Prediction_Final.pptx`: Final presentation deck
- `Employee_Retention_Prediction_Submission.zip`: Final zip package for submission

## Project Contents

- `app.py`: Streamlit application for interactive prediction
- `run_app.bat`: Windows launcher for the Streamlit app
- `requirements.txt`: Python dependencies used for this project
- `aug_train.csv`: Training dataset
- `aug_test.csv`: Test dataset
- `outputs/`: Generated model artifacts, figures, evaluation files, and predictions

## Model Summary

The project compares Logistic Regression, Random Forest, XGBoost, and LightGBM using a validation split.

- XGBoost achieved the highest ROC-AUC: `0.8167`
- Random Forest achieved the highest F1-score: `0.6323`
- LightGBM achieved the highest accuracy: `0.7985`

The saved deployment model used by the app is stored at `outputs/models/best_model.pkl`.

## Setup

1. Create and activate a Python environment.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

## Run The App

Use either of these options from the project folder:

```bash
python -m streamlit run app.py
```

or on Windows:

```bat
run_app.bat
```

The app loads the trained pipeline from `outputs/models/best_model.pkl`.

## Key Outputs

- `outputs/models/best_model.pkl`: Saved trained pipeline used by the app
- `outputs/model_comparison.csv`: Model comparison summary
- `outputs/predictions/final_test_predictions.csv`: Predictions for `aug_test.csv`
- `outputs/01_data_quality_report.csv`: Data quality summary
- `Employee_Retention_Prediction_Report.docx`: Final written report
- `Employee_Retention_Prediction_Final.pptx`: Final presentation
- `Employee_Retention_Prediction_Submission.zip`: Final packaged submission

## Notes

- The notebook contains the complete analysis workflow requested in the project brief.
- The report and presentation summarize the business problem, methodology, results, and recommendations.
- The app accepts unseen city values and warns when the city was not present during training.
- The project uses project-relative paths so the folder remains portable across machines.
